package com.example.musicquiz;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void submitButtonFunction(View view){
        int score = 0;

        // Checks the correct answers for question 1
        RadioButton a1JD_CheckBox = (RadioButton) findViewById(R.id.a1JD);
        Boolean a1JDAnswer = a1JD_CheckBox.isChecked();
        if (a1JDAnswer == true) {
            score = score +1;
        }

        // Checks the correct answers for question 2
        RadioButton a2_0_CheckBox = (RadioButton) findViewById(R.id.a2_0);
        Boolean a2_0Answer = a2_0_CheckBox.isChecked();
        if (a2_0Answer == true) {
            score = score +1;
        }

        // Checks the correct answers for question 3
        CheckBox a3_1_CheckBox = (CheckBox) findViewById(R.id.a3_1);
        Boolean a3_1Answer = a3_1_CheckBox.isChecked();
        if (a3_1Answer == true) {
            score = score +1;
        }
        CheckBox a3_5_CheckBox = (CheckBox) findViewById(R.id.a3_5);
        Boolean a3_5Answer = a3_5_CheckBox.isChecked();
        if (a3_5Answer == true) {
            score = score +1;
        }

       //Checks the answer for question 4 by getting the value of camelsNameTextBox which should be CLYDE
        EditText userEnteredName = (EditText) findViewById(R.id.camelsNameTextBox);
        String camelName = userEnteredName.getText().toString();
        if (camelName.equalsIgnoreCase("Clyde")) {
            score = score + 1;
        }

//        Close the keyboard ~ Thank You Google search
        InputMethodManager imm = (InputMethodManager) getSystemService (Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, 0);

        if (score == 5) {
            String scoreMessage = "Perfect!!  You got " + score + " Correct answers of 5 possible";
            Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show();
        } else {
            String scoreMessage = score + " Correct answers of 5 possible";
            Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show();
        }

    }

}
